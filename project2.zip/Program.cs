﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Project2
{
    class employee
    {
        public int empid, deptid, projects, projid;
        public string empname, empmail, deptname, projname;
        public string empphn;

        public void getemployee()
        {
            Console.WriteLine("ENTER THE EMPLOYEE ID:          ");
            empid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE EMPLOYEE NAME:        ");
            empname = Console.ReadLine();
            Console.WriteLine("ENTER THE EMPLOYEE PHONE:       ");
            empphn = Console.ReadLine();
            Console.WriteLine("ENTER THE EMPLOYEE MAILID:      ");
            empmail = Console.ReadLine();
            Console.WriteLine("ENTER THE DEPARTMENT ID:        ");
            deptid = int.Parse(Console.ReadLine());
        }
        public void getdepartment()
        {
            Console.WriteLine("ENTER THE DEPARTMENT ID:        ");
            deptid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE DEPARTMENT NAME:        ");
            deptname = Console.ReadLine();
            Console.WriteLine("ENTER THE NO OF PROJECTS:        ");
            projects = int.Parse(Console.ReadLine());
        }
        public void getprojects()
        {
            Console.WriteLine("ENTER THE PROJECT ID:        ");
            projid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE DEPARTMENT ID:     ");
            deptid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE PROJECT NAME:        ");
            projname = Console.ReadLine();
            Console.WriteLine("ENTER THE EMPLOYEE  ID:        ");
            empid = int.Parse(Console.ReadLine());
        }
        public string empdisplay()
        {
            return (empid.ToString().PadLeft(20) + "|" + empname.PadLeft(20) + "|" + empmail.PadLeft(20) + "|" + empphn.PadLeft(20) + "|" + deptid.ToString().PadLeft(20) + "|");
        }
        public string deptdisplay()
        {
            return (deptid.ToString().PadLeft(20) + "|" + deptname.PadLeft(20) + "|" + projects.ToString().PadLeft(20) + "|");
        }
        public string projdisplay()
        {
            return (projid.ToString().PadLeft(20) + "|" + deptid.ToString().PadLeft(20) + "|" + projname.PadLeft(20) + "|" + empid.ToString().PadLeft(20) + "|");
        }

    }
}
