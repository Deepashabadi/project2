﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Project2
{
    class Program2
    {

        public static string deptid1 = "", mngrid = "";

        static void Main(string[] args)
        {


            int flag = 1;
            while (flag == 1)
            {
                int ch;

                Console.WriteLine("1 Insert Employee/Department/projects  2.Searching the employee with common department   3.Searching all the projects with same empid and print details of employee    4.Exit   5v.Printing projects based on dept name  ");
                Console.WriteLine("Enter your choice");
                ch = int.Parse(Console.ReadLine());
                string filename1 = @"C:\Users\deepa\Desktop\Employee.txt";
                string filename2 = @"C:\Users\deepa\Desktop\Department.txt ";
                string filename3 = @" C:\Users\deepa\Desktop\Projects.txt";
                int value1 = 1;
                int value2 = 2;
                int value3 = 3;

                switch (ch)
                {
                    case 1:
                        int p = 1;
                        while (p == 1)
                        {
                            Console.WriteLine("INSERT  1.employee  2.department  3.projects");
                            int ch1 = int.Parse(Console.ReadLine());
                            if (ch1 == 1)
                                writefiles(filename1, ch1);
                            else if (ch1 == 2)
                                writefiles(filename2, ch1);
                            else if (ch1 == 3)
                                writefiles(filename3, ch1);
                            else if (ch1 == 4)
                                p = 0;
                            else
                                Console.WriteLine("Enter the correct choice");
                        }
                        break;

                    case 2:
                        Console.WriteLine("ENTER THE DEPARTMENT NAME TO BE SEARCHED");
                        string val = Console.ReadLine();

                        readfiles(filename2, value2, val);
                        readfiles(filename1, value1, deptid1);
                        break;
                    case 3:
                        Console.WriteLine("ENTER THE MANAGER EMPLOYEE ID TO BE SEARCHED");
                        int ch2 = int.Parse(Console.ReadLine());


                        readfiles(filename3, value3, ch2.ToString());

                        readfiles(filename1, value1, mngrid);
                        break;
                    case 4: flag = 0; break;
                    case 5:
                        Console.WriteLine("ENTER THE DEPARTMENT NAME TO BE SEARCHED");
                        string val1 = Console.ReadLine();

                        readfiles(filename2, value2, val1);
                        readfiles(filename3, value3, deptid1);
                        break;
                    default: Console.WriteLine("Enter the correct option"); break;



                }
            }
        }
        public static void writefiles(string filename, int ch1)
        {
            employee ob = new employee();

            StreamWriter sw = new StreamWriter(filename, true);
            using (sw)
            {
                switch (ch1)
                {
                    case 1: ob.getemployee(); sw.WriteLine(ob.empdisplay()); break;
                    case 2: ob.getdepartment(); sw.WriteLine(ob.deptdisplay()); break;
                    case 3: ob.getprojects(); sw.WriteLine(ob.projdisplay()); break;
                    default: Console.WriteLine("WRONG CHOICE"); break;
                }
            }
            sw.Close();
        }
        public static void readfiles(string filename, int value, string key)
        {

            StreamReader sr1 = new StreamReader(filename, true);
            using (sr1)
            {
                string[] lines = File.ReadAllLines(filename);

                foreach (string line in lines)
                {
                    string[] words = line.Split('|');
                    foreach (string i in words)
                    {
                        if (value == 2 && key == words[1].Trim())
                            deptid1 = words[0].Trim();
                        if (value == 1 && key == words[4].Trim())
                        {
                            Console.WriteLine(words[0] + words[1] + words[2] + words[3] + words[4]);
                            break;
                        }
                        else if (value == 1 && key == words[0].Trim())
                        {
                            Console.WriteLine(words[0] + words[1] + words[2] + words[3] + words[4]);
                            break;
                        }
                        if(value == 3 && key == words[3].Trim())
                        {
                            mngrid = words[3].Trim();
                        }
                       else if (value == 3 && key == words[1].Trim())
                        {
                            
                            Console.WriteLine(words[0] + words[1] + words[2] + words[3]);
                            break;
                        }
                    }
                }
            }
            sr1.Close();
        }
    }
}
                   
